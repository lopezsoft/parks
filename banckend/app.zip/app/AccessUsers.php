<?php

namespace App;

use App\core\CoreModel;

class AccessUsers extends CoreModel
{
    //
    protected   $table  = "tb_access_users";
}
