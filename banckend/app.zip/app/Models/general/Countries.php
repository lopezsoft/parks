<?php

namespace App\Models\general;

use App\core\CoreModel;

class Countries extends CoreModel
{
    protected $table    = 'tb_countries';
}
