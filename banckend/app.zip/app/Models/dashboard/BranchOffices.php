<?php

namespace App\Models\dashboard;

use App\core\CoreModel;

class BranchOffices extends CoreModel
{
    protected $table    = 'tb_branch_offices';
}
