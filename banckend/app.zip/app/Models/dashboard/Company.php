<?php

namespace App\Models\dashboard;

use App\core\CoreModel;

class Company extends CoreModel
{

    protected $table    = 'tb_company';
}
