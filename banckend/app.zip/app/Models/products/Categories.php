<?php

namespace App\Models\products;

use App\core\CoreModel;

class Categories extends CoreModel
{
    protected $table    = "tb_product categories";
}
