<?php

namespace App\Models\products;
use App\core\CoreModel;


class Products extends CoreModel
{
    protected $table    = 'tb_products';
}
