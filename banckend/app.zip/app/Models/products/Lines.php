<?php

namespace App\Models\products;

use App\core\CoreModel;

class Lines extends CoreModel
{
    protected $table    = "tb_product_lines";
}
