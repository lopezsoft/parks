<?php

namespace App\Models\sales;

use App\core\CoreModel;

class DetailFootWear extends CoreModel
{
    protected   $table  = 'tb_sales_detail_footwear';
}
