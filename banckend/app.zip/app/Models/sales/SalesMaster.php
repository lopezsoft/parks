<?php

namespace App\Models\sales;

use App\core\CoreModel;

class SalesMaster extends CoreModel
{
    protected $table    = 'tb_sales_master';
}
