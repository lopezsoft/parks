<?php

namespace App\Models\sales;

use App\core\CoreModel;

class SalesDetail extends CoreModel
{
    protected $table    = 'tb_sales_detail';
}
