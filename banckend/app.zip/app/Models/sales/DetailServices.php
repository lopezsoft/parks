<?php

namespace App\Models\sales;

use App\core\CoreModel;

class DetailServices extends CoreModel
{
    protected $table    = 'tb_sales_detail_services';
}
