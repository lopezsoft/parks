<?php

namespace App;

use App\core\CoreModel;

class Roles extends CoreModel
{
    //
    protected $table  = 'tb_roles';
}
